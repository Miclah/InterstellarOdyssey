package game.entity;

public interface Talkable {
    public void talk();
}
