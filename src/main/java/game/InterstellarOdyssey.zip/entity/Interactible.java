package game.entity;

public interface Interactible {
    // follow player
    // react to player changes
    public void interact();
}
