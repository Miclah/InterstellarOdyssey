package game.entity;

import game.items.ShopInventory;
import javafx.scene.image.Image;

import java.util.ArrayList;
import java.util.HashMap;

public abstract class ShopKeeper extends NPC implements Interactible, Talkable{

    private double discount;
    private boolean sale;
    private ShopInventory inventory;

    public ShopKeeper(int worldX, int worldY, String name, ArrayList<Image> frames, HashMap<RelationshipType, String> dialogue, int relation) {
        super(worldX, worldY, name, frames, dialogue, relation);
        this.discount = 0;
        this.sale = false;
        this.inventory = new ShopInventory();
    }

    public double getDiscount() {
        return this.discount;
    }

    public boolean isSale() {
        return this.sale;
    }

    public void setSale(boolean sale) {
        this.sale = !sale;
    }

    public void setDiscount(double discount) {
        if (discount < 0) {
            this.discount = 0;
        } else if (discount > 100) {
            this.discount = 100;
        } else {
            this.discount = discount;
        }
    }

    @Override
    public void talk() {

    }
}
