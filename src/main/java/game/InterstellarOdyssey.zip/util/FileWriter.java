package game.util;

public class FileWriter {


}
