package game.items;

import java.util.ArrayList;

public class ShopInventory {
    private ArrayList<Item> inventory;

    public ShopInventory() {
        this.inventory = new ArrayList<>();
    }

    public ArrayList<Item> getInventory() {
        return this.inventory;
    }

    public void addItem(Item item) {
        if (!this.inventory.contains(item)) {
            this.inventory.add(item);
        }
    }

    public void removeItem(Item item) {
        this.inventory.remove(item);
    }
}
